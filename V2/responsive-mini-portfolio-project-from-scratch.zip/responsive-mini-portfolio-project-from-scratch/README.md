# 💼 Responsive Mini Portfolio
## [Watch it on youtube]()
### 💼 Responsive Mini Portfolio

- Responsive mini portfolio website Using HTML CSS & JavaScript
- Contains animations css.
- Includes a light and dark mode.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
